QT += widgets sql
CONFIG += c++11
TEMPLATE = app
TARGET = experiment
SOURCES += main.cpp archive.cpp
HEADERS += archive.h
msvc: QMAKE_CXXFLAGS += /utf-8
