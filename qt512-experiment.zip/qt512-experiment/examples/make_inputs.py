"""Generate two sets of importable waveform and camera files."""
import math
import struct
from pathlib import Path

out = Path(__file__).resolve().parent / "generated"
out.mkdir(exist_ok=True)

for run, rate, shift in [(1, 1000, 0.0), (2, 800, 0.14)]:
    with (out / f"run{run}.f32").open("wb") as signal:
        for sample in range(rate):
            t = sample / rate
            signal.write(struct.pack("<ff", math.sin(2 * math.pi * 5 * (t - shift)),
                                     math.cos(2 * math.pi * 3 * (t - shift))))

    for camera, period in [("A", 40_000), ("B", 50_000)]:
        width, height = 160, 120
        frames = 800_000 // period + 1
        with (out / f"run{run}_camera{camera}.gseq").open("wb") as sequence:
            sequence.write(struct.pack("<4s5I", b"GSEQ", 1, width, height, frames, period))
            for frame in range(frames):
                t = frame * period / 1_000_000
                cx = 25 + 100 * t + 8 * (run - 1)
                cy = 45 if camera == "A" else 75
                sequence.write(bytes(
                    240 if (x - cx) ** 2 + (y - cy) ** 2 < 14 ** 2 else 25 + x // 4
                    for y in range(height) for x in range(width)
                ))
