#include "archive.h"

#include <QDataStream>
#include <QFile>
#include <QJsonDocument>
#include <QSqlError>
#include <QStringList>
#include <QUuid>
#include <algorithm>
#include <cmath>
#include <cstring>

namespace {
void require(bool ok, const QString &message)
{
    if (!ok)
        throw message;
}

QByteArray readBytes(QFile &file, qint64 size)
{
    const auto bytes = file.read(size);
    require(bytes.size() == size, QStringLiteral("原始文件读取不完整"));
    return bytes;
}

void configure(QDataStream &stream, QDataStream::FloatingPointPrecision precision)
{
    stream.setByteOrder(QDataStream::LittleEndian);
    stream.setFloatingPointPrecision(precision);
}
}

Archive::Archive(const QString &path)
    : name_(QUuid::createUuid().toString()), db_(QSqlDatabase::addDatabase("QSQLITE", name_))
{
    try {
        db_.setConnectOptions("QSQLITE_BUSY_TIMEOUT=5000");
        db_.setDatabaseName(path);
        require(db_.open(), db_.lastError().text());
        query("PRAGMA foreign_keys=ON");
        transaction([&] {
            auto version = query("PRAGMA user_version");
            require(version.next(), QStringLiteral("无法识别数据库版本"));
            const int current = version.value(0).toInt();
            version.finish();
            require(current == 0 || current == 1, QStringLiteral("数据库版本不受支持"));
            if (current == 1)
                return;
            query("CREATE TABLE runs(id INTEGER PRIMARY KEY, number TEXT NOT NULL UNIQUE,"
                  " started TEXT NOT NULL, duration REAL NOT NULL CHECK(duration>=0),"
                  " condition TEXT NOT NULL, parameters TEXT NOT NULL)");
            query("CREATE TABLE datasets(id INTEGER PRIMARY KEY, run_id INTEGER NOT NULL"
                  " REFERENCES runs(id) ON DELETE CASCADE, kind INTEGER NOT NULL CHECK(kind BETWEEN 0 AND 4),"
                  " key TEXT NOT NULL, x_unit TEXT NOT NULL, y_unit TEXT NOT NULL,"
                  " count INTEGER NOT NULL CHECK(count>0), start REAL NOT NULL, period REAL NOT NULL,"
                  " width INTEGER NOT NULL, height INTEGER NOT NULL, UNIQUE(run_id,kind,key))");
            query("CREATE TABLE parts(dataset_id INTEGER NOT NULL REFERENCES datasets(id) ON DELETE CASCADE,"
                  " part INTEGER NOT NULL, bytes BLOB NOT NULL, PRIMARY KEY(dataset_id,part)) WITHOUT ROWID");
            query("PRAGMA user_version=1");
        });
    } catch (...) {
        db_.close();
        db_ = QSqlDatabase();
        QSqlDatabase::removeDatabase(name_);
        throw;
    }
}

Archive::~Archive()
{
    db_.close();
    db_ = QSqlDatabase();
    QSqlDatabase::removeDatabase(name_);
}

QSqlQuery Archive::query(const QString &sql, const QVariantList &args)
{
    QSqlQuery q(db_);
    require(q.prepare(sql), q.lastError().text());
    for (const auto &arg : args)
        q.addBindValue(arg);
    require(q.exec(), q.lastError().text());
    return q;
}

void Archive::transaction(const std::function<void()> &work)
{
    require(db_.transaction(), db_.lastError().text());
    try {
        work();
        require(db_.commit(), db_.lastError().text());
    } catch (...) {
        db_.rollback();
        throw;
    }
}

QVector<Run> Archive::runs()
{
    QVector<Run> rows;
    auto q = query("SELECT id,number,started,condition,parameters,duration FROM runs"
                   " ORDER BY julianday(started) DESC,id DESC");
    while (q.next())
        rows.append({q.value(0).toLongLong(), q.value(1).toString(), q.value(2).toString(),
                     q.value(3).toString(), q.value(4).toString(), q.value(5).toDouble()});
    require(!q.lastError().isValid(), q.lastError().text());
    return rows;
}

QVector<Dataset> Archive::datasets(qint64 run)
{
    QVector<Dataset> rows;
    auto q = query("SELECT id,kind,key,x_unit,y_unit,count,start,period,width,height"
                   " FROM datasets WHERE run_id=? ORDER BY kind,key", {run});
    while (q.next())
        rows.append({q.value(0).toLongLong(), Kind(q.value(1).toInt()), q.value(2).toString(),
                     q.value(3).toString(), q.value(4).toString(), q.value(5).toLongLong(),
                     q.value(6).toDouble(), q.value(7).toDouble(), q.value(8).toInt(), q.value(9).toInt()});
    require(!q.lastError().isValid(), q.lastError().text());
    return rows;
}

qint64 Archive::addRun(const Run &run)
{
    require(!run.number.trimmed().isEmpty() && std::isfinite(run.duration) && run.duration >= 0
            && QDateTime::fromString(run.when, Qt::ISODateWithMs).isValid(),
            QStringLiteral("请检查试验编号、开始时间和时长"));
    require(QJsonDocument::fromJson(run.parameters.toUtf8()).isObject(),
            QStringLiteral("附加参数必须是 JSON 对象"));
    return query("INSERT INTO runs(number,started,duration,condition,parameters) VALUES(?,?,?,?,?)",
                 {run.number.trimmed(), run.when, run.duration, QStringLiteral("") + run.condition,
                  run.parameters}).lastInsertId().toLongLong();
}

void Archive::removeRuns(const QVector<qint64> &runs)
{
    transaction([&] {
        for (auto run : runs)
            query("DELETE FROM runs WHERE id=?", {run});
    });
}

qint64 Archive::insert(qint64 run, Kind kind, const QString &key, const QString &xUnit,
                       const QString &yUnit, qint64 count, double start, double period,
                       int width, int height)
{
    require(!key.trimmed().isEmpty(), QStringLiteral("数据标识不能为空"));
    return query("INSERT INTO datasets(run_id,kind,key,x_unit,y_unit,count,start,period,width,height)"
                 " VALUES(?,?,?,?,?,?,?,?,?,?)",
                 {run, int(kind), key.trimmed(), QStringLiteral("") + xUnit, QStringLiteral("") + yUnit,
                  count, start, period, width, height}).lastInsertId().toLongLong();
}

void Archive::put(qint64 dataset, qint64 part, const QByteArray &bytes)
{
    query("INSERT INTO parts(dataset_id,part,bytes) VALUES(?,?,?)", {dataset, part, bytes});
}

void Archive::importWave(qint64 run, const QString &path, const QStringList &keys,
                         const QString &unit, double start, double rate, qint64 offset)
{
    require(!keys.isEmpty() && keys.size() <= 64 && std::isfinite(start)
            && std::isfinite(rate) && rate > 0, QStringLiteral("请检查通道数和采样时间参数"));
    QFile file(path);
    require(file.open(QIODevice::ReadOnly), file.errorString());
    const int stride = keys.size() * 4;
    require(offset >= 0 && offset < file.size() && (file.size() - offset) % stride == 0
            && file.seek(offset), QStringLiteral("文件长度或偏移与通道数不匹配"));
    const qint64 count = (file.size() - offset) / stride;
    require(std::isfinite(1 / rate) && std::isfinite(start + (count - 1) / rate),
            QStringLiteral("采样时间超出数值范围"));
    transaction([&] {
        QVector<qint64> ids;
        for (const auto &key : keys)
            ids.append(insert(run, Wave, key, "s", unit, count, start, 1 / rate));
        for (qint64 first = 0, part = 0; first < count; ++part) {
            const int size = int(qMin<qint64>(8192, count - first));
            const auto block = readBytes(file, size * stride);
            for (int channel = 0; channel < ids.size(); ++channel) {
                QByteArray bytes(size * 4, Qt::Uninitialized);
                for (int i = 0; i < size; ++i)
                    std::memcpy(bytes.data() + i * 4, block.constData() + i * stride + channel * 4, 4);
                put(ids[channel], part, bytes);
            }
            first += size;
        }
    });
}

void Archive::importImages(qint64 run, const QString &path, const QString &key)
{
    QFile file(path);
    require(file.open(QIODevice::ReadOnly), file.errorString());
    require(readBytes(file, 4) == "GSEQ", QStringLiteral("文件标识必须是 GSEQ"));
    quint32 version, width, height, frames, periodUs;
    QDataStream header(&file);
    header.setByteOrder(QDataStream::LittleEndian);
    header >> version >> width >> height >> frames >> periodUs;
    require(header.status() == QDataStream::Ok && version == 1 && width > 0 && height > 0
            && width <= 8192 && height <= 8192 && frames > 0 && periodUs > 0,
            QStringLiteral("GSEQ 文件头无效或版本不受支持"));
    const qint64 frameBytes = qint64(width) * height;
    require(file.size() >= 24 && (file.size() - 24) % frameBytes == 0
            && (file.size() - 24) / frameBytes == frames,
            QStringLiteral("GSEQ 文件长度与文件头不匹配"));
    transaction([&] {
        const auto id = insert(run, Image, key, "s", "", frames, 0, periodUs / 1e6, width, height);
        for (quint32 i = 0; i < frames; ++i)
            put(id, i, readBytes(file, frameBytes));
    });
}

void Archive::saveResult(qint64 run, Kind kind, const QString &key, const QString &xUnit,
                         const QString &yUnit, const QVector<QPointF> &points)
{
    require((kind == Scalar || kind == Array || kind == Curve) && !points.isEmpty()
            && (kind != Scalar || points.size() == 1), QStringLiteral("分析结果数量无效"));
    transaction([&] {
        query("DELETE FROM datasets WHERE run_id=? AND kind=? AND key=?", {run, int(kind), key.trimmed()});
        const auto id = insert(run, kind, key, xUnit, yUnit, points.size());
        for (int first = 0, part = 0; first < points.size(); ++part) {
            QByteArray bytes;
            QDataStream stream(&bytes, QIODevice::WriteOnly);
            configure(stream, QDataStream::DoublePrecision);
            const int size = qMin(8192, points.size() - first);
            for (int i = first; i < first + size; ++i) {
                const auto &point = points[i];
                require(std::isfinite(point.x()) && std::isfinite(point.y()), QStringLiteral("分析结果含非有限数值"));
                stream << point.x() << point.y();
            }
            require(stream.status() == QDataStream::Ok, QStringLiteral("分析结果编码失败"));
            put(id, part, bytes);
            first += size;
        }
    });
}

QVector<QPointF> Archive::points(const Dataset &data, bool forDisplay)
{
    require(data.kind != Image && data.count > 0, QStringLiteral("曲线数据无效"));
    QVector<QPointF> output;
    // 按顺序保留每个分组的极小和极大值，绘制长记录时仍可看到尖峰。
    const qint64 bucket = forDisplay ? (data.count - 1) / 3000 + 1 : 1;
    QPointF low, high;
    qint64 lowIndex = -1, highIndex = -1;
    auto flush = [&] {
        if (lowIndex < 0)
            return;
        if (highIndex < lowIndex)
            output.append(high);
        output.append(low);
        if (highIndex > lowIndex)
            output.append(high);
        lowIndex = highIndex = -1;
    };
    qint64 index = 0;
    auto q = query("SELECT bytes FROM parts WHERE dataset_id=? ORDER BY part", {data.id});
    const int size = data.kind == Wave ? 4 : 16;
    while (q.next()) {
        const auto bytes = q.value(0).toByteArray();
        require(bytes.size() % size == 0, QStringLiteral("曲线数据块损坏"));
        QDataStream stream(bytes);
        configure(stream, data.kind == Wave ? QDataStream::SinglePrecision : QDataStream::DoublePrecision);
        for (int at = 0; at < bytes.size(); at += size, ++index) {
            double x = data.start + index * data.period;
            double y;
            if (data.kind != Wave)
                stream >> x;
            stream >> y;
            const QPointF point(x, y);
            if (!forDisplay) {
                output.append(point);
                continue;
            }
            if (!std::isfinite(x) || !std::isfinite(y)) {
                flush();
                if (output.isEmpty() || std::isfinite(output.last().y()))
                    output.append(point);
            } else {
                if (lowIndex < 0 || y < low.y()) {
                    low = point;
                    lowIndex = index;
                }
                if (highIndex < 0 || y > high.y()) {
                    high = point;
                    highIndex = index;
                }
            }
            if ((index + 1) % bucket == 0)
                flush();
        }
    }
    require(!q.lastError().isValid(), q.lastError().text());
    require(index == data.count, QStringLiteral("曲线采样点数不匹配"));
    flush();
    return output;
}

QImage Archive::frame(const Dataset &data, qint64 index)
{
    require(data.kind == Image && index >= 0 && index < data.count
            && data.width > 0 && data.width <= 8192 && data.height > 0 && data.height <= 8192,
            QStringLiteral("帧索引或图像尺寸无效"));
    auto q = query("SELECT bytes FROM parts WHERE dataset_id=? AND part=?", {data.id, index});
    require(q.next(), QStringLiteral("数据库中缺少该帧"));
    const auto bytes = q.value(0).toByteArray();
    require(bytes.size() == data.width * data.height, QStringLiteral("图像帧数据长度不匹配"));
    QImage image(data.width, data.height, QImage::Format_Grayscale8);
    require(!image.isNull(), QStringLiteral("无法分配图像内存"));
    image.fill(0);
    for (int y = 0; y < data.height; ++y)
        std::memcpy(image.scanLine(y), bytes.constData() + y * data.width, data.width);
    return image;
}
