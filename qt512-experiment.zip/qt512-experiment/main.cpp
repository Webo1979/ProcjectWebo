#include "archive.h"

#include <QApplication>
#include <QAbstractItemView>
#include <QComboBox>
#include <QCommandLineParser>
#include <QDateTimeEdit>
#include <QDialog>
#include <QDialogButtonBox>
#include <QDir>
#include <QDoubleSpinBox>
#include <QFileDialog>
#include <QFormLayout>
#include <QHeaderView>
#include <QItemSelectionModel>
#include <QLabel>
#include <QLineEdit>
#include <QMainWindow>
#include <QMessageBox>
#include <QPainter>
#include <QPainterPath>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QRegularExpression>
#include <QScrollArea>
#include <QSignalBlocker>
#include <QSlider>
#include <QSplitter>
#include <QStackedWidget>
#include <QStandardPaths>
#include <QStatusBar>
#include <QStringList>
#include <QTableWidget>
#include <QVBoxLayout>
#include <algorithm>
#include <cmath>

namespace {
QString kindName(Kind kind)
{
    return QStringList{QStringLiteral("原始曲线"), QStringLiteral("序列图像"),
                       QStringLiteral("特征值"), QStringLiteral("特征数组"),
                       QStringLiteral("特征曲线")}.value(kind);
}

QString datasetLabel(const Dataset &data)
{
    QString label = kindName(data.kind) + QStringLiteral("  ·  ") + data.key;
    if (!data.xUnit.isEmpty() || !data.yUnit.isEmpty())
        label += QStringLiteral("  [%1%2%3]").arg(data.xUnit,
                 data.xUnit.isEmpty() || data.yUnit.isEmpty() ? "" : " / ", data.yUnit);
    return label;
}

struct Series {
    QString name;
    QVector<QPointF> points;
};

class Plot : public QWidget {
public:
    Plot() { setMinimumSize(380, 250); }

    QVector<Series> series;
    QString xUnit, yUnit;

protected:
    void paintEvent(QPaintEvent *) override
    {
        QPainter p(this);
        p.fillRect(rect(), Qt::white);
        p.setRenderHint(QPainter::Antialiasing);
        const QRectF area = QRectF(rect()).adjusted(78, 24, -24, -60);
        double xmin = 0, xmax = 0, ymin = 0, ymax = 0;
        bool found = false;
        for (const auto &line : series) {
            for (const auto &pt : line.points) {
                if (!std::isfinite(pt.x()) || !std::isfinite(pt.y()))
                    continue;
                if (!found) {
                    xmin = xmax = pt.x();
                    ymin = ymax = pt.y();
                    found = true;
                }
                xmin = qMin(xmin, pt.x());
                xmax = qMax(xmax, pt.x());
                ymin = qMin(ymin, pt.y());
                ymax = qMax(ymax, pt.y());
            }
        }
        if (!found) {
            p.drawText(rect(), Qt::AlignCenter, QStringLiteral("没有可绘制的数据"));
            return;
        }
        const auto fraction = [](double v, double lo, double hi) {
            if (lo == hi)
                return 0.5;
            const double span = hi - lo;
            if (std::isfinite(span))
                return (v - lo) / span;
            return (v / 2 - lo / 2) / (hi / 2 - lo / 2);
        };
        for (int i = 0; i <= 5; ++i) {
            const double ratio = i / 5.0;
            const double x = area.left() + (xmin == xmax ? 0.5 : ratio) * area.width();
            const double y = area.bottom() - (ymin == ymax ? 0.5 : ratio) * area.height();
            p.setPen(QColor("#e4ebf3"));
            if (xmin != xmax || i == 0)
                p.drawLine(QPointF(x, area.top()), QPointF(x, area.bottom()));
            if (ymin != ymax || i == 0)
                p.drawLine(QPointF(area.left(), y), QPointF(area.right(), y));
            p.setPen(QColor("#40516a"));
            if (xmin != xmax || i == 0)
                p.drawText(QRectF(x - 31, area.bottom() + 5, 62, 20), Qt::AlignCenter,
                           QString::number(xmin * (1 - ratio) + xmax * ratio, 'g', 5));
            if (ymin != ymax || i == 0)
                p.drawText(QRectF(3, y - 10, 68, 20), Qt::AlignRight | Qt::AlignVCenter,
                           QString::number(ymin * (1 - ratio) + ymax * ratio, 'g', 5));
        }
        p.drawRect(area);
        p.drawText(QRectF(area.left(), area.bottom() + 28, area.width(), 22),
                   Qt::AlignCenter, QStringLiteral("横轴  %1").arg(xUnit));
        p.drawText(8, 15, QStringLiteral("纵轴  %1").arg(yUnit));
        p.setClipRect(area.adjusted(-2, -2, 2, 2));
        for (int i = 0; i < series.size(); ++i) {
            p.setPen(QPen(color(i), 1.8));
            QPainterPath path;
            bool active = false;
            for (const auto &pt : series[i].points) {
                if (!std::isfinite(pt.x()) || !std::isfinite(pt.y())) {
                    active = false;
                    continue;
                }
                const QPointF mapped(area.left() + fraction(pt.x(), xmin, xmax) * area.width(),
                                     area.bottom() - fraction(pt.y(), ymin, ymax) * area.height());
                if (active) {
                    path.lineTo(mapped);
                } else {
                    path.moveTo(mapped);
                    p.drawEllipse(mapped, 2, 2);
                }
                active = true;
            }
            p.drawPath(path);
        }
    }

public:
    static QColor color(int index)
    {
        return QColor::fromHsv(int((qint64(index) * 137 + 205) % 360), 195, 185);
    }
};

class FrameView : public QWidget {
public:
    FrameView() { setMinimumSize(200, 160); }
    QImage image;
    QString message;

    void paintEvent(QPaintEvent *) override
    {
        QPainter p(this);
        p.fillRect(rect(), QColor("#162235"));
        if (image.isNull()) {
            p.setPen(Qt::white);
            p.drawText(rect(), Qt::AlignCenter | Qt::TextWordWrap, message);
            return;
        }
        const QSize size = image.size().scaled(this->size(), Qt::KeepAspectRatio);
        const QRect target(QPoint((width() - size.width()) / 2, (height() - size.height()) / 2), size);
        p.drawImage(target, image);
    }
};

class Form : public QDialog {
public:
    Form(QWidget *parent, const QString &title) : QDialog(parent)
    {
        setWindowTitle(title);
        auto *layout = new QVBoxLayout(this);
        fields = new QFormLayout;
        layout->addLayout(fields);
        auto *buttons = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
        buttons->button(QDialogButtonBox::Ok)->setText(QStringLiteral("保存"));
        buttons->button(QDialogButtonBox::Cancel)->setText(QStringLiteral("取消"));
        connect(buttons, &QDialogButtonBox::accepted, this, &QDialog::accept);
        connect(buttons, &QDialogButtonBox::rejected, this, &QDialog::reject);
        layout->addWidget(buttons);
        resize(510, sizeHint().height());
    }

    QLineEdit *line(const QString &label, const QString &initial = {})
    {
        auto *edit = new QLineEdit(initial);
        fields->addRow(label, edit);
        return edit;
    }

    QLineEdit *file(const QString &label)
    {
        auto *row = new QWidget;
        auto *layout = new QHBoxLayout(row);
        layout->setContentsMargins(0, 0, 0, 0);
        auto *edit = new QLineEdit;
        auto *button = new QPushButton(QStringLiteral("浏览…"));
        layout->addWidget(edit, 1);
        layout->addWidget(button);
        fields->addRow(label, row);
        connect(button, &QPushButton::clicked, this, [this, edit] {
            const auto path = QFileDialog::getOpenFileName(this, QStringLiteral("选择原始数据文件"));
            if (!path.isEmpty())
                edit->setText(path);
        });
        return edit;
    }

    QFormLayout *fields;
};

class Window : public QMainWindow {
public:
    explicit Window(Archive &archive) : db(archive)
    {
        setWindowTitle(QStringLiteral("试验数据管理"));
        resize(1190, 755);
        auto *body = new QWidget;
        setCentralWidget(body);
        auto *outer = new QVBoxLayout(body);
        outer->setContentsMargins(18, 15, 18, 15);
        outer->setSpacing(12);
        auto *title = new QLabel(QStringLiteral("试验数据管理"));
        title->setObjectName("title");
        outer->addWidget(title);
        auto *actions = new QHBoxLayout;
        outer->addLayout(actions);
        auto *add = new QPushButton(QStringLiteral("新增发次"));
        auto *remove = new QPushButton(QStringLiteral("删除所选发次"));
        waveButton = new QPushButton(QStringLiteral("导入波形…"));
        imageButton = new QPushButton(QStringLiteral("导入序列图像…"));
        resultButton = new QPushButton(QStringLiteral("保存分析结果…"));
        for (auto *button : {add, remove, waveButton, imageButton, resultButton})
            actions->addWidget(button);
        actions->addStretch();

        auto *split = new QSplitter;
        outer->addWidget(split, 1);
        auto *left = new QWidget;
        auto *leftLayout = new QVBoxLayout(left);
        leftLayout->setContentsMargins(0, 0, 8, 0);
        leftLayout->addWidget(new QLabel(QStringLiteral("发次列表  ·  Ctrl / Shift 多选")));
        table = new QTableWidget(0, 3);
        table->setHorizontalHeaderLabels({QStringLiteral("编号"), QStringLiteral("试验开始"), QStringLiteral("时长 / s")});
        table->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
        table->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
        table->horizontalHeader()->setSectionResizeMode(2, QHeaderView::ResizeToContents);
        table->verticalHeader()->hide();
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->setSelectionMode(QAbstractItemView::ExtendedSelection);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        table->setAlternatingRowColors(true);
        leftLayout->addWidget(table, 1);
        details = new QPlainTextEdit;
        details->setReadOnly(true);
        details->setMaximumHeight(160);
        leftLayout->addWidget(details);
        split->addWidget(left);

        auto *right = new QWidget;
        auto *rightLayout = new QVBoxLayout(right);
        rightLayout->setContentsMargins(8, 0, 0, 0);
        auto *selector = new QHBoxLayout;
        selector->addWidget(new QLabel(QStringLiteral("显示项目")));
        choice = new QComboBox;
        choice->setSizeAdjustPolicy(QComboBox::AdjustToMinimumContentsLengthWithIcon);
        choice->setMinimumContentsLength(18);
        selector->addWidget(choice, 1);
        rightLayout->addLayout(selector);
        view = new QStackedWidget;
        rightLayout->addWidget(view, 1);
        empty = new QLabel(QStringLiteral("选择发次并导入数据，或保存分析结果"));
        empty->setAlignment(Qt::AlignCenter);
        view->addWidget(empty);
        auto *curvePage = new QWidget;
        auto *curveLayout = new QVBoxLayout(curvePage);
        plot = new Plot;
        legend = new QLabel;
        legend->setWordWrap(true);
        curveLayout->addWidget(plot, 1);
        curveLayout->addWidget(legend);
        view->addWidget(curvePage);
        scalarTable = new QTableWidget(0, 2);
        scalarTable->setHorizontalHeaderLabels({QStringLiteral("发次"), QStringLiteral("特征值")});
        scalarTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        scalarTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
        view->addWidget(scalarTable);

        auto *imagePage = new QWidget;
        auto *imageLayout = new QVBoxLayout(imagePage);
        auto *scroll = new QScrollArea;
        scroll->setWidgetResizable(true);
        auto *panels = new QWidget;
        panes = new QHBoxLayout(panels);
        scroll->setWidget(panels);
        imageLayout->addWidget(scroll, 1);
        auto *timeLayout = new QHBoxLayout;
        timeLayout->addWidget(new QLabel(QStringLiteral("试验相对时间")));
        slider = new QSlider(Qt::Horizontal);
        timeLayout->addWidget(slider, 1);
        seconds = new QDoubleSpinBox;
        seconds->setDecimals(6);
        seconds->setSuffix(" s");
        timeLayout->addWidget(seconds);
        imageLayout->addLayout(timeLayout);
        view->addWidget(imagePage);
        split->addWidget(right);
        split->setSizes({390, 760});
        setStyleSheet("QMainWindow { background:#f2f6fb; } QLabel#title {font-size:25px;"
                      "font-weight:bold;color:#182c46;} QPushButton {padding:7px 12px;}"
                      "QTableWidget,QPlainTextEdit {border:1px solid #cfd9e6;}"
                      "QHeaderView::section {background:#e4edf8;padding:6px;border:0;}");
        connect(add, &QPushButton::clicked, this, [this] { attempt([&] { addRun(); }); });
        connect(remove, &QPushButton::clicked, this, [this] { attempt([&] { deleteRuns(); }); });
        connect(waveButton, &QPushButton::clicked, this, [this] { attempt([&] { importRaw(Wave); }); });
        connect(imageButton, &QPushButton::clicked, this, [this] { attempt([&] { importRaw(Image); }); });
        connect(resultButton, &QPushButton::clicked, this, [this] { attempt([&] { saveResult(); }); });
        connect(table, &QTableWidget::itemSelectionChanged, this, [this] { attempt([&] { refresh(); }); });
        connect(choice, QOverload<int>::of(&QComboBox::currentIndexChanged),
                this, [this] { attempt([&] { display(); }); });
        connect(slider, &QSlider::valueChanged, this, [this](int value) {
            seconds->setValue(value * seconds->maximum() / qMax(1, slider->maximum()));
        });
        connect(seconds, QOverload<double>::of(&QDoubleSpinBox::valueChanged), this, [this](double time) {
            const QSignalBlocker block(slider);
            if (seconds->maximum() > 0)
                slider->setValue(qRound(time / seconds->maximum() * slider->maximum()));
            attempt([&] { renderFrames(time); });
        });
        reload();
    }

private:
    struct Selection {
        Run run;
        QVector<Dataset> data;
    };

    struct ImagePanel {
        const Dataset *data;
        FrameView *widget;
        QLabel *caption;
    };

    Archive &db;
    QVector<Run> runs;
    QVector<Selection> selected;
    QVector<Dataset> options;
    QVector<ImagePanel> frames;
    QTableWidget *table, *scalarTable;
    QPlainTextEdit *details;
    QComboBox *choice;
    QStackedWidget *view;
    QLabel *empty, *legend;
    Plot *plot;
    QHBoxLayout *panes;
    QSlider *slider;
    QDoubleSpinBox *seconds;
    QPushButton *waveButton, *imageButton, *resultButton;

    void attempt(const std::function<void()> &fn)
    {
        try {
            fn();
        } catch (const QString &message) {
            QMessageBox::warning(this, QStringLiteral("操作失败"), message);
        }
    }

    QVector<int> selectedRows() const
    {
        QVector<int> rows;
        for (const auto &index : table->selectionModel()->selectedRows())
            rows.append(index.row());
        std::sort(rows.begin(), rows.end());
        return rows;
    }

    void reload(qint64 selectId = 0)
    {
        runs = db.runs();
        {
            const QSignalBlocker block(table);
            table->clearSelection();
            table->setRowCount(runs.size());
            for (int row = 0; row < runs.size(); ++row) {
                const auto &run = runs[row];
                table->setItem(row, 0, new QTableWidgetItem(run.number));
                table->setItem(row, 1, new QTableWidgetItem(run.when));
                table->setItem(row, 2, new QTableWidgetItem(QString::number(run.duration, 'g', 12)));
                if (run.id == selectId)
                    table->selectRow(row);
            }
        }
        refresh();
    }

    void addRun()
    {
        Form form(this, QStringLiteral("新增发次"));
        auto *number = form.line(QStringLiteral("试验编号"));
        auto *date = new QDateTimeEdit(QDateTime::currentDateTime());
        date->setCalendarPopup(true);
        date->setDisplayFormat("yyyy-MM-dd HH:mm:ss.zzz");
        form.fields->addRow(QStringLiteral("开始日期和时刻"), date);
        auto *duration = new QDoubleSpinBox;
        duration->setDecimals(6);
        duration->setMaximum(1e9);
        duration->setSuffix(" s");
        form.fields->addRow(QStringLiteral("时长"), duration);
        auto *condition = form.line(QStringLiteral("工况"));
        auto *parameters = new QPlainTextEdit("{}");
        parameters->setMaximumHeight(92);
        form.fields->addRow(QStringLiteral("附加参数（JSON）"), parameters);
        while (form.exec() == QDialog::Accepted) {
            try {
                const auto when = date->dateTime();
                const auto fixedOffset = when.toOffsetFromUtc(when.offsetFromUtc());
                const auto id = db.addRun({0, number->text(), fixedOffset.toString(Qt::ISODateWithMs),
                                           condition->text(), parameters->toPlainText(), duration->value()});
                reload(id);
                return;
            } catch (const QString &message) {
                QMessageBox::warning(&form, QStringLiteral("保存失败"), message);
            }
        }
    }

    void deleteRuns()
    {
        const auto rows = selectedRows();
        if (rows.isEmpty())
            return;
        const auto reply = QMessageBox::question(this, QStringLiteral("删除发次"),
            QStringLiteral("删除选中的 %1 个发次及其原始数据、分析结果？").arg(rows.size()),
            QMessageBox::Yes | QMessageBox::Cancel, QMessageBox::Cancel);
        if (reply != QMessageBox::Yes)
            return;
        QVector<qint64> ids;
        for (int row : rows)
            ids.append(runs[row].id);
        db.removeRuns(ids);
        reload();
    }

    void importRaw(Kind kind)
    {
        if (selected.size() != 1)
            return;
        const auto run = selected.first().run.id;
        Form form(this, kind == Wave ? QStringLiteral("导入浮点波形") : QStringLiteral("导入 GSEQ 序列图像"));
        auto *path = form.file(QStringLiteral("原始数据文件"));
        auto *key = form.line(kind == Wave ? QStringLiteral("通道标识（逗号分隔）") : QStringLiteral("相机通道标识"));
        QLineEdit *unit = nullptr, *rate = nullptr, *offset = nullptr, *start = nullptr;
        if (kind == Wave) {
            unit = form.line(QStringLiteral("信号单位"));
            rate = form.line(QStringLiteral("采样率 / Hz"), "1000");
            offset = form.line(QStringLiteral("文件头偏移 / 字节"), "0");
            start = form.line(QStringLiteral("首样本相对时刻 / s"), "0");
        }
        while (form.exec() == QDialog::Accepted) {
            try {
                if (kind == Wave) {
                    bool rateOk, startOk, offsetOk;
                    const double hz = rate->text().toDouble(&rateOk);
                    const double time = start->text().toDouble(&startOk);
                    const qint64 bytes = offset->text().toLongLong(&offsetOk);
                    if (!rateOk || !startOk || !offsetOk)
                        throw QStringLiteral("采样率、首样本时刻和偏移应为有效数值");
                    db.importWave(run, path->text(), key->text().split(QRegularExpression("[,，]")),
                                  unit->text().trimmed(), time, hz, bytes);
                } else {
                    db.importImages(run, path->text(), key->text());
                }
                refresh();
                statusBar()->showMessage(QStringLiteral("原始数据已导入"), 4000);
                return;
            } catch (const QString &message) {
                QMessageBox::warning(&form, QStringLiteral("导入失败"), message);
            }
        }
    }

    void saveResult()
    {
        if (selected.size() != 1)
            return;
        const auto run = selected.first().run.id;
        Form form(this, QStringLiteral("保存分析结果"));
        auto *kindInput = new QComboBox;
        for (Kind kind : {Scalar, Array, Curve})
            kindInput->addItem(kindName(kind), int(kind));
        form.fields->addRow(QStringLiteral("类型"), kindInput);
        auto *key = form.line(QStringLiteral("结果标识"));
        key->setPlaceholderText(QStringLiteral("例  camera1.edge_position"));
        auto *yUnit = form.line(QStringLiteral("结果单位"));
        auto *xUnit = form.line(QStringLiteral("曲线横轴单位"));
        auto *values = new QPlainTextEdit;
        form.fields->addRow(QStringLiteral("结果数据"), values);
        auto updateFields = [&] {
            const Kind kind = Kind(kindInput->currentData().toInt());
            xUnit->setEnabled(kind == Curve);
            values->setPlaceholderText(kind == Scalar ? QStringLiteral("输入一个数值")
                : kind == Array ? QStringLiteral("输入多个数值，以逗号或换行分隔")
                : QStringLiteral("每行一对 X,Y，以逗号或空格分隔"));
        };
        connect(kindInput, QOverload<int>::of(&QComboBox::currentIndexChanged), &form, updateFields);
        updateFields();
        while (form.exec() == QDialog::Accepted) {
            try {
                const Kind kind = Kind(kindInput->currentData().toInt());
                const auto text = values->toPlainText().trimmed();
                QVector<QPointF> points;
                auto number = [](const QString &value) {
                    bool ok;
                    const double result = value.toDouble(&ok);
                    if (!ok || !std::isfinite(result))
                        throw QStringLiteral("分析结果包含无效数值");
                    return result;
                };
                if (kind == Curve) {
                    for (const auto &row : text.split('\n')) {
                        if (row.trimmed().isEmpty())
                            continue;
                        const auto pair = row.trimmed().split(QRegularExpression("[,，\\s]+"));
                        if (pair.size() != 2)
                            throw QStringLiteral("特征曲线每行需要一对 X,Y");
                        points.append(QPointF(number(pair[0]), number(pair[1])));
                    }
                } else {
                    const auto tokens = text.split(QRegularExpression("[,，\\s]+"));
                    for (const auto &token : tokens)
                        points.append(QPointF(points.size(), number(token)));
                }
                const QString axis = kind == Curve ? xUnit->text().trimmed()
                    : kind == Array ? QStringLiteral("元素索引") : QStringLiteral("");
                db.saveResult(run, kind, key->text(), axis, yUnit->text().trimmed(), points);
                refresh();
                statusBar()->showMessage(QStringLiteral("分析结果已保存"), 4000);
                return;
            } catch (const QString &message) {
                QMessageBox::warning(&form, QStringLiteral("保存失败"), message);
            }
        }
    }

    static bool same(const Dataset &a, const Dataset &b)
    {
        return a.kind == b.kind && a.key == b.key && a.xUnit == b.xUnit && a.yUnit == b.yUnit;
    }

    void refresh()
    {
        const auto prior = choice->currentText();
        frames.clear();
        selected.clear();
        options.clear();
        for (int row : selectedRows()) {
            selected.append({runs[row], db.datasets(runs[row].id)});
            for (const auto &data : selected.last().data) {
                if (std::none_of(options.cbegin(), options.cend(),
                                 [&](const Dataset &item) { return same(item, data); }))
                    options.append(data);
            }
        }
        {
            const QSignalBlocker block(choice);
            choice->clear();
            for (const auto &item : options)
                choice->addItem(datasetLabel(item));
            const int previous = choice->findText(prior);
            choice->setCurrentIndex(previous < 0 && !options.isEmpty() ? 0 : previous);
        }
        const bool one = selected.size() == 1;
        waveButton->setEnabled(one);
        imageButton->setEnabled(one);
        resultButton->setEnabled(one);
        QStringList lines;
        for (const auto &selection : selected) {
            const auto &run = selection.run;
            lines << QStringLiteral("%1  ·  工况  %2\n附加参数  %3")
                     .arg(run.number, run.condition, run.parameters);
        }
        details->setPlainText(lines.join("\n\n"));
        display();
    }

    const Dataset *match(const Selection &item, const Dataset &key) const
    {
        for (const auto &data : item.data) {
            if (same(data, key))
                return &data;
        }
        return nullptr;
    }

    void display()
    {
        frames.clear();
        view->setCurrentIndex(0);
        if (choice->currentIndex() < 0)
            return;
        const auto &key = options[choice->currentIndex()];
        if (key.kind == Image) {
            while (auto *item = panes->takeAt(0)) {
                delete item->widget();
                delete item;
            }
            double end = 0;
            for (const auto &selection : selected) {
                const auto *data = match(selection, key);
                auto *panel = new QWidget;
                auto *layout = new QVBoxLayout(panel);
                auto *caption = new QLabel;
                caption->setTextFormat(Qt::PlainText);
                auto *image = new FrameView;
                layout->addWidget(caption);
                layout->addWidget(image, 1);
                panes->addWidget(panel, 1);
                frames.append({data, image, caption});
                if (data)
                    end = qMax(end, (data->count - 1) * data->period);
            }
            {
                const QSignalBlocker a(slider), b(seconds);
                slider->setRange(0, end > 0 ? 10000 : 0);
                slider->setValue(0);
                seconds->setRange(0, end);
                seconds->setValue(0);
            }
            renderFrames(0);
            view->setCurrentIndex(3);
        } else if (key.kind == Scalar) {
            scalarTable->setRowCount(selected.size());
            scalarTable->setHorizontalHeaderItem(1, new QTableWidgetItem(
                key.yUnit.isEmpty() ? QStringLiteral("特征值") : key.yUnit));
            for (int i = 0; i < selected.size(); ++i) {
                const auto &item = selected[i];
                const auto *data = match(item, key);
                scalarTable->setItem(i, 0, new QTableWidgetItem(item.run.number));
                scalarTable->setItem(i, 1, new QTableWidgetItem(data
                    ? QString::number(db.points(*data).first().y(), 'g', 16)
                    : QStringLiteral("无匹配数据")));
            }
            view->setCurrentIndex(2);
        } else {
            plot->series.clear();
            plot->xUnit = key.xUnit;
            plot->yUnit = key.yUnit;
            QStringList labels;
            for (const auto &item : selected) {
                const auto *data = match(item, key);
                const auto name = item.run.number.toHtmlEscaped();
                if (data) {
                    const auto color = Plot::color(plot->series.size()).name();
                    labels << QStringLiteral("<span style='color:%1'>● %2</span>").arg(color, name);
                    plot->series.append({item.run.number, db.points(*data, true)});
                } else {
                    labels << QStringLiteral("%1（无匹配数据）").arg(name);
                }
            }
            legend->setText(labels.join(QStringLiteral("　")));
            plot->update();
            view->setCurrentIndex(1);
        }
    }

    void renderFrames(double time)
    {
        for (int i = 0; i < frames.size(); ++i) {
            auto &panel = frames[i];
            const auto *data = panel.data;
            panel.widget->image = QImage();
            panel.caption->setText(selected[i].run.number);
            if (!data) {
                panel.widget->message = QStringLiteral("无匹配数据");
            } else if (time > (data->count - 1) * data->period + 0.0000001) {
                panel.widget->message = QStringLiteral("超出帧时间范围");
            } else {
                const auto index = qMin(data->count - 1, qRound64(time / data->period));
                try {
                    panel.widget->image = db.frame(*data, index);
                    panel.caption->setText(QStringLiteral("%1  ·  第 %2 / %3 帧  ·  %4 s")
                        .arg(selected[i].run.number).arg(index + 1).arg(data->count)
                        .arg(index * data->period, 0, 'f', 6));
                } catch (const QString &message) {
                    panel.widget->message = message;
                }
            }
            panel.widget->update();
        }
    }
};
}

int main(int argc, char **argv)
{
    QApplication app(argc, argv);
    app.setApplicationName("ExperimentArchive");
    QCommandLineParser parser;
    parser.setApplicationDescription(QStringLiteral("试验数据管理"));
    parser.addHelpOption();
    parser.addPositionalArgument("database", QStringLiteral("SQLite 数据库文件路径"), "[database]");
    parser.process(app);
    QString path;
    if (!parser.positionalArguments().isEmpty()) {
        path = parser.positionalArguments().first();
    } else {
        const auto folder = QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation);
        if (folder.isEmpty() || !QDir().mkpath(folder)) {
            QMessageBox::critical(nullptr, QStringLiteral("启动失败"), QStringLiteral("无法创建数据库目录"));
            return 1;
        }
        path = QDir(folder).filePath("experiments.sqlite");
    }
    try {
        Archive archive(path);
        Window window(archive);
        window.statusBar()->showMessage(QDir::toNativeSeparators(path));
        window.show();
        return app.exec();
    } catch (const QString &message) {
        QMessageBox::critical(nullptr, QStringLiteral("数据库打开失败"), message);
        return 1;
    }
}
