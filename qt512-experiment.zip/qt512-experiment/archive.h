#pragma once
#include <QDateTime>
#include <QImage>
#include <QPointF>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>
#include <QVector>
#include <functional>

enum Kind { Wave, Image, Scalar, Array, Curve };

struct Run {
    qint64 id;
    QString number, when, condition, parameters;
    double duration;
};

struct Dataset {
    qint64 id;
    Kind kind;
    QString key, xUnit, yUnit;
    qint64 count;
    double start, period;
    int width, height;
};

class Archive {
public:
    explicit Archive(const QString &path);
    ~Archive();
    Archive(const Archive &) = delete;
    Archive &operator=(const Archive &) = delete;
    QVector<Run> runs();
    QVector<Dataset> datasets(qint64 run);
    qint64 addRun(const Run &run);
    void removeRuns(const QVector<qint64> &runs);
    void importWave(qint64 run, const QString &path, const QStringList &keys,
                    const QString &unit, double start, double rate, qint64 offset);
    void importImages(qint64 run, const QString &path, const QString &key);
    void saveResult(qint64 run, Kind kind, const QString &key, const QString &xUnit,
                    const QString &yUnit, const QVector<QPointF> &points);
    QVector<QPointF> points(const Dataset &data, bool forDisplay = false);
    QImage frame(const Dataset &data, qint64 index);

private:
    QString name_;
    QSqlDatabase db_;
    QSqlQuery query(const QString &sql, const QVariantList &args = {});
    void transaction(const std::function<void()> &work);
    qint64 insert(qint64 run, Kind kind, const QString &key, const QString &xUnit,
                  const QString &yUnit, qint64 count, double start = 0, double period = 0,
                  int width = 0, int height = 0);
    void put(qint64 dataset, qint64 part, const QByteArray &bytes);
};
